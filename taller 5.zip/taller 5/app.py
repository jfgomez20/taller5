

from flask import Flask, request, jsonify, render_template, g
from flask_cors import CORS, cross_origin
from neo4j import GraphDatabase, basic_auth
URL = "bolt://localhost:7687"
USERNAME = "neo4j"
PASSWORD = "1234"
DATABASE = "taller5"

app = Flask(__name__)


driver = GraphDatabase.driver(URL, auth = basic_auth(USERNAME, PASSWORD))
db = driver.session(database = DATABASE)

@app.route('/')
def index():
    if not hasattr(g,'neo4'):
        g.neo4 = driver.session()
        print(g.neo4)
    return render_template('formularioVendedor.html')

@app.route('/crearv', methods=["POST"])
def crearv():
    
    if request.method == 'POST':
        vendedor = request.form['vendedor']
        producto = request.form['producto']
        summary = db.write_transaction(lambda tx: tx.run("CREATE (n:Vendedor {name: '"+vendedor+"'})-[:SELL]->(n:Producto {name: '"+producto+"'})").consume())
        summary.counters.properties_set
    
    return render_template('formularioComprador.html')

@app.route('/compra', methods=["POST"])
def compra():

    if request.method == "POST":
        comprador = request.form['comprador']
        producto1 = request.form['producto']
        calificacion = request.form['cal']
        summary = db.write_transaction(lambda tx: tx.run("MATCH (p:Producto {name: "+producto1+"}) CREATE (c:Comprador {name: "+comprador+"}) CREATE (c)-[:BUY]->(I) CREATE (c)-[:"+calificacion+"]->(i)").consume())
        summary.counters.properties_set
    return render_template('index.html')
if __name__ == '__main__':
    app.run(host='127.0.0.1', debug=True)